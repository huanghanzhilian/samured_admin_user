//
//  MYFPhone.h
//  MYFPhone
//
//  Created by 拾光 on 2017/3/24.
//  Copyright © 2017年 丶拾光. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef NS_ENUM(NSInteger, ErrorCode) {
    
    ErrorCodeSuccess  =0,//成功
    ErrorCodeSignFail   =1 ,//签名验证失败
    /*
        若认证通过之后出现网络异常，则是因为未使用移动运营商网络访问，需要切换到运营商网络
     */
    ErrorCodeNetworkError     =404,//网络异常

    /*
        获取手机号码时 网络环境必须是使用运营商网络访问，连接WIFI无法成功；
        在使用运营商网络访问的情况下，不同运营商获取成功率不同，获取失败后请多试几次
     */
    ErrorCodeGetPhoneFail     =2001,//获取号码失败
    
};


@interface MYFPhone : NSObject

+ (void)getPhoneNumberWithAppId:(NSString*)appId sign:(NSString*)sign finish:(void(^)(NSDictionary * result))block;


+ (void)showLog:(BOOL)show;


+(void)getTestAppIDAndSign:(void(^)(NSDictionary*))block;

@end




